# Minimal GitLab Subgroup via Terraform (CI-ready)

Creates a subgroup under your parent group. If the subgroup exists, the pipeline imports it into Terraform state; otherwise Terraform creates it.

## Configure CI/CD Variables
- `GITLAB_TOKEN` (required) — PAT with `api` scope
- `GITLAB_BASE_URL` — default: `https://gitlab.com` (set only if self-managed)
- `PARENT_GROUP_PATH` — e.g. `chris`
- `SUBGROUP_NAME` — e.g. `automation`
- `SUBGROUP_PATH` — e.g. `automation` (URL-safe)

## Files
- `.gitlab-ci.yml` — plans & applies; auto-imports subgroup if it already exists
- `terraform/main.tf`, `terraform/variables.tf`, `terraform/versions.tf`
