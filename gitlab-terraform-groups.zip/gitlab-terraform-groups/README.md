# GitLab Group Chain Manager (Terraform + CI)

Creates any missing GitLab group/subgroup in a path like `chris/devops/automation/terraform`,
imports existing groups into Terraform state, and (optionally) stops the pipeline if nothing new is needed.

## How it works
1) `ci/ensure_path.py` walks each prefix of `TARGET_PATH`, checks it via GitLab API, creates if missing,
   and imports IDs into Terraform state (`gitlab_group.groups["<full_path>"]`).
2) Terraform plans/applies the managed chain (entire path or only the leaf).

## Required CI Variables
- `GITLAB_TOKEN` (PAT with `api` scope)
- `TARGET_PATH` (e.g., `chris/devops/automation/terraform`)

### Optional
- `STOP_IF_ALL_EXIST` = `true` | `false` (default `false`)
- `MANAGE_CHAIN` = `true` | `false` (default `true`)
- `VISIBILITY` = `private` | `internal` | `public` (default `private`)
- `GITLAB_BASE_URL` = `https://gitlab.com` or your self-managed URL (default `https://gitlab.com`)
