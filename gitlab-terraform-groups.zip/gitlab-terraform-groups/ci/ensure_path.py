#!/usr/bin/env python3
import os, sys, json, urllib.parse, urllib.request

BASE_URL         = os.environ.get("GITLAB_BASE_URL", "https://gitlab.com").rstrip("/")
API              = f"{BASE_URL}/api/v4"
TOKEN            = os.environ.get("GITLAB_TOKEN") or os.environ.get("CI_JOB_TOKEN")
FULL_PATH        = os.environ["TARGET_PATH"].strip("/")
VISIBILITY       = os.environ.get("VISIBILITY", "private")
STOP_IF_ALL_EXIST= os.environ.get("STOP_IF_ALL_EXIST", "false").lower() == "true"
MANAGE_CHAIN     = os.environ.get("MANAGE_CHAIN", "true").lower() == "true"

if not TOKEN:
    print("Missing GITLAB_TOKEN/CI_JOB_TOKEN", file=sys.stderr); sys.exit(2)

def request(method, url, data=None):
    headers = {"PRIVATE-TOKEN": TOKEN}
    if data is not None:
        body = urllib.parse.urlencode(data).encode("utf-8")
        headers["Content-Type"] = "application/x-www-form-urlencoded"
    else:
        body = None
    req = urllib.request.Request(url, data=body, headers=headers, method=method)
    try:
        with urllib.request.urlopen(req) as r:
            raw = r.read()
            if raw:
                return json.loads(raw.decode("utf-8")), r.getcode()
            return None, r.getcode()
    except urllib.error.HTTPError as e:
        if e.code == 404:
            return None, 404
        print(f"HTTP {e.code} for {url}\n{e.read().decode('utf-8')}", file=sys.stderr)
        sys.exit(1)

def get_group(full_path):
    enc = urllib.parse.quote(full_path, safe="")
    return request("GET", f"{API}/groups/{enc}")

def create_group(name, parent_id=None):
    data = {"name": name, "path": name, "visibility": VISIBILITY}
    if parent_id:
        data["parent_id"] = str(parent_id)
    return request("POST", f"{API}/groups", data=data)

segs = FULL_PATH.split("/")
prefixes = ["/".join(segs[:i]) for i in range(1, len(segs)+1)]

result = []
created_any = False
parent_id = None

for p in prefixes:
    meta, code = get_group(p)
    if code == 200:
        gid = meta["id"]
        created = False
    else:
        name = p.split("/")[-1]
        meta, _ = create_group(name, parent_id=parent_id)
        gid = meta["id"]
        created = True
        created_any = True
    result.append({"full_path": p, "id": gid, "created": created})
    parent_id = gid

with open("ensure.json", "w") as f:
    json.dump(result, f, indent=2)

if STOP_IF_ALL_EXIST and not created_any:
    print("All groups already exist; stopping as requested.", file=sys.stderr)
    sys.exit(3)

import_paths = prefixes if MANAGE_CHAIN else [FULL_PATH]
for p in import_paths:
    gid = next(item["id"] for item in result if item["full_path"] == p)
    addr = f'gitlab_group.groups["{p}"]'
    os.system(f'terraform import -allow-missing-config "{addr}" "{gid}" >/dev/null 2>&1')

print("OK")
